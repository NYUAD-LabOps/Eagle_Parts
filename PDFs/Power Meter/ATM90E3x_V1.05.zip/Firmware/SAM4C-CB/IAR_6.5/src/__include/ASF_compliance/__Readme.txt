cmsis_iar.h : 	extract from IAR 6.10 (lib version 6.10.5.52324) (....\arm\CMSIS\Include)
compiler.h : to be cleaned !!!!!