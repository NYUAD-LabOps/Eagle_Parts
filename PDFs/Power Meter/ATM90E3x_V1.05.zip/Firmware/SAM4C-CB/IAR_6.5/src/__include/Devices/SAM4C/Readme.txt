Extract date : 19 Nov 2012
Recieved by Email from Patrick Filipi

