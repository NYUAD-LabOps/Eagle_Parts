//===================================================================
#include "target.h"
//-------------------------------------------------------------------
extern sys_t	        sys;		    // system parameters

COM_Str    VCom;
AFE_MODIFY_Str	VAFE_MODIFY;
//-------------------------------------------------------------------

/// @cond 0
/**INDENT-OFF**/
#ifdef __cplusplus
extern "C" {
#endif
/**INDENT-ON**/
/// @endcond

uint32_t	SendStringToCMBuff( const uint8_t *sptr, uint8_t *mptr );

//===================================================================
//decription    ::  UART0 interrupt process
//function      ::  UART0_IrqHandler
//input         ::  none
//output        ::  none
//call          ::  UART_IntProc
//effect        ::  none
//===================================================================
void UART0_IrqHandler( void )
{
    UART_IntProc( UART0, &VCom.Rs485 );
}
//===================================================================
//decription    ::  UART1 interrupt process
//function      ::  UART1_IrqHandler
//input         ::  none
//output        ::  none
//call          ::  UART_IntProc
//effect        ::  none
//===================================================================
void	UART1_IrqHandler( void )
{
    UART_IntProc( UART1, &VCom.IR );
}
//===================================================================
//decription    ::  UART interrupt process
//function      ::  UART_IntProc
//input         ::  UARTx,ptr
//output        ::  none
//call          ::  none
//effect        ::  none
//===================================================================
void UART_IntProc( Uart *UARTx, UART_str *ptr )
{
    uint32_t ul_status;
    uint8_t data;
    TASK_CONST	taskid;
    //Read USART Status.
    ul_status = uart_get_status( UARTx ); //read uart status

    if ( ptr->state == CMDPROCESS || ptr->state == SEND )
    {
        uart_read( UARTx, &data ); //read uart receive register
        return;
    }
    switch ( ptr->protocolmode )
    {
        case	IEC_PROTOCOL:
        {
            if ( ptr->state != SEND )
            {
                if ( !( ul_status & US_CSR_RXRDY ) )
                {
                    break;
                }
                if ( ptr == &VCom.Rs485 )
                {
                    taskid = Rs485CmdProc;
                }
                uart_read( UARTx, &data ); //read uart receive register
                ptr->overtimer = 0;
                //----------ack uart-----------------------
                uart_write( UARTx, data );	//ack uart
                //-----------------------------------------
                if ( is_char( data ) )
                {
                    data = upper( data );
                }
                ptr->buff[ptr->offset] = data;

                if ( data == 0x0D )		//Enter =0x0D
                {
                    ptr->state = CMDPROCESS;
                    ptr->Flag.BIT.OneFrameFlag = 1;
                    PutTaskIntoQue_INT( taskid );
                }
                if ( ++ptr->offset >= FRAME_MAX_LEN )
                {
                    ptr->state = FREE;
                    ptr->Flag.BYTE = 0;
                    ptr->offset = 0;
                    ptr->protocolmode = DLT645_PROTOCOL;
                }
            }//endif( !=SEND )
            else
            {
            }//it is (SEND)
        }//end case IEC
        break;
        default :
            break;
    }
}
//===================================================================
//decription    ::  USART2 interrupt process
//function      ::  USART2_IrqHandler
//input         ::  none
//output        ::  none
//call          ::  USART_IntProc
//effect        ::  none
//===================================================================
void	USART2_IrqHandler( void )
{
    USART_IntProc( USART2, &VCom.ZigBee );
}
//===================================================================
//decription    ::  USART3 interrupt process
//function      ::  USART3_IrqHandler
//input         ::  none
//output        ::  none
//call          ::  USART_IntProc
//effect        ::  none
//===================================================================
void	USART3_IrqHandler( void )
{
    USART_IntProc( USART3, &VCom.PLC );
}
//===================================================================
//decription    ::  USART interrupt process
//function      ::  USART_IntProc
//input         ::  Usartx,ptr
//output        ::  none
//call          ::  PutTaskIntoQue_INT
//effect        ::  none
//===================================================================
void	USART_IntProc( Usart *Usartx, UART_str *ptr )
{
}

//===================================================================
//decription    ::  inition uart process
//function      ::  Init_Uart
//input         ::  uart_id
//output        ::  none
//call          ::  uart_init
//effect        ::  none
//===================================================================
void	Init_Uart_App( UART_TYPE uart_id )
{
    volatile int i;
    Uart *Uartx;
    UART_str *ptr;
    uint32_t	mode = 0;
    switch ( uart_id )
    {
        case	Rs485_ID:
        {
            Uartx = UART0;
            ptr = &VCom.Rs485;

            pio_configure( PINS_UART0_PIO, PINS_UART0_TYPE, PINS_UART0_MASK, PINS_UART0_ATTR );
            pmc_enable_periph_clk( ID_UART0 );
        }
        break;
        case	Ir_ID:
        {
            PMC->CKGR_PLLAR = 0;	//disable plla

            Uartx = UART1;
            ptr = &VCom.IR;

            pio_configure( PINS_UART1_PIO, PINS_UART1_TYPE, PINS_UART1_MASK, PINS_UART1_ATTR );
            pmc_enable_periph_clk( ID_UART1 );

            PMC->CKGR_PLLAR = 0x00BC6401;	//mul=188,count=100,en=1
            while ( ( PMC->PMC_SR & PMC_SR_LOCKA ) == 0 );
            mode |= UART_MR_OPT_CLKDIV( 12 ) | UART_MR_OPT_DUTY_DUTY_50 | UART_MR_OPT_MDINV_DISABLED | UART_MR_OPT_EN_DISABLED;
            //UART1->UART_MR |=UART_MR_OPT_CLKDIV(12) | UART_MR_OPT_DUTY_DUTY_50 | UART_MR_OPT_MDINV_DISABLED | UART_MR_OPT_EN_DISABLED;
        }
        break;
    }//
    i =	sysclk_get_cpu_hz();
    if ( uart_id == Rs485_ID )
    {
        switch ( ptr->baud_sym )
        {
            case	0x80:
            {
                ptr->baud_ID = Baud_115200;
            }
            break;
            case	0x40:
            {
                ptr->baud_ID = Baud_9600;
            }
            break;
            case	0x20:
            {
                ptr->baud_ID = Baud_4800;
            }
            break;
            case	0x10:
            {
                ptr->baud_ID = Baud_2400;
            }
            break;
            case	0x08:
            {
                ptr->baud_ID = Baud_1200;
            }
            break;
            case	0x04:
            {
                ptr->baud_ID = Baud_600;
            }
            break;
            case	0x02:
            {
                ptr->baud_ID = Baud_300;
            }
            break;
            default:
                ptr->baud_ID = Baud_4800;
        }
    }
    if ( uart_id == Ir_ID )
    {
        ptr->baud_ID = Baud_1200;
    }
    ptr->Flag.BYTE = 0;

    mode |= UART_MR_PAR_EVEN; //UART_MR_PAR_NO;
    ptr->offset = 0;
    ptr->len = 0;
    ptr->overtimer = 0;
    ptr->sendtimer = 0;
    ptr->state = FREE;
    ptr->protocolmode = IEC_PROTOCOL; //IEC_PROTOCOL;
    const sam_uart_opt_t uart_console_settings =
    { i, ptr->baud_ID, mode };
    uart_init( Uartx, &uart_console_settings );

    uart_enable_interrupt( Uartx, US_IER_RXRDY );
    if ( uart_id == Rs485_ID )
    {
        NVIC_EnableIRQ( UART0_IRQn );
    }
    if ( uart_id == Ir_ID )
    {
        //Uartx->UART_MR |=( UART_MR_OPT_EN_ENABLED | UART_MR_OPT_CMPTH_VDDIO_DIV2 | UART_MR_OPT_DUTY_DUTY_50 | UART_MR_OPT_CLKDIV(18) );//F=(Fmck*10/10)/8/(18+8)=
        NVIC_EnableIRQ( UART1_IRQn );
    }
}
//===================================================================
//decription    ::  communication send process
//function      ::  ComSendProcess
//input         ::  uart_id
//output        ::  none
//call          ::  none
//effect        ::  none
//===================================================================
void	ComSendProcess( UART_TYPE uart_id )
{
    TASK_CONST sendid;
    UART_str	*ptr;
    ptr = &VCom.Rs485;
    if ( uart_id == Ir_ID )
    {
        ptr = &VCom.IR;
        //--------------modulation send--------------------
        UART1->UART_MR |= UART_MR_OPT_CLKDIV( 12 ) | UART_MR_OPT_DUTY_DUTY_50 | UART_MR_OPT_MDINV_DISABLED;
        UART1->UART_MR |= UART_MR_OPT_EN_ENABLED;
        //-------------------------------------------------
    }
    if ( uart_id == PLC_ID )
    {
        ptr = &VCom.PLC;
    }
    if ( uart_id == ZigBee_ID )
    {
        ptr = &VCom.ZigBee;
    }
    if ( ptr->state == SEND )
    {
        if ( ( ptr->len != 0 ) && ( ptr->offset < FRAME_MAX_LEN ) )
        {
            switch ( uart_id )
            {
                case	Rs485_ID:
                {
                    uart_write( UART0, ptr->buff[ptr->offset++] );
                    while ( !( uart_get_status( UART0 ) & US_CSR_TXRDY ) );
                    sendid = Rs485Transmit;
                }
                break;
                case	Ir_ID:
                {
                    uart_write( UART1, ptr->buff[ptr->offset++] );
                    while ( !( uart_get_status( UART1 ) & US_CSR_TXRDY ) );
                    sendid = IrTransmit;
                }
                break;
                case	ZigBee_ID:
                {
                    gpio_set_pin_high( PIN_USART2_RE_IDX );	//usart2 is send status
                    usart_write( USART2, ptr->buff[ptr->offset++] );
                    while ( !( usart_get_status( USART2 ) & US_CSR_TXRDY ) );
                    sendid = ZigBeeTransmit;
                }
                break;
                case	PLC_ID:
                {
                    usart_write( USART3, ptr->buff[ptr->offset++] );
                    while ( !( usart_get_status( USART3 ) & US_CSR_TXRDY ) );
                    sendid = PLCTransmit;
                }
                break;
            }
            if ( --ptr->len != 0 )
            {
                PutTaskIntoQue( sendid );
                ptr->overtimer = 0;
            }
            else
            {
                ptr->overtimer = 957;
            }
        }
    }
}

//===================================================================
//decription    ::  send string to communication buffer
//function      ::  SendStringToCMBuf
//input         ::  sptr->string
//					mptr->communication buffer
//output        ::  string len<=35
//call          ::  none
//effect        ::  none
//===================================================================
uint32_t	SendStringToCMBuff( const uint8_t *sptr, uint8_t *mptr )
{
    uint32_t	i, j;
    j = 0;
    for ( i = 0; i < 36; i++ )
    {
        if ( ( *( sptr + i ) ) == NULL )
        {
            break;
        }
        *( mptr + i ) = *( sptr + i );
        j++;
    }
    return ( j );
}

//===================================================================
//decription    ::  get configure afe parameter from communication
//function      ::  cmd_get_afe_config_data
//input         ::  ptr->data first address
//output        ::  1: data format is correct, 0: data format is error
//call          ::  is_num
//effect        ::  VAFE_MODIFY
//===================================================================
uint32_t	cmd_get_afe_config_data( uint8_t *ptr )
{
    uint32_t	i, k, m, n;
    m = 0;	    //calibration data num
    n = 0;		//decimal num
    k = 0;      //calibration data
    for ( i = 0; i < 15; i++ )
    {
        if ( *( ptr + i ) == '(' )
        {
            break;
        }
    }
    if ( i >= 10 )
    {
        return ( 0 );
    }
    for ( i = i + 1; i < 180; i++ )
    {
        if ( *( ptr + i ) == ')' )
        {
            break;
        }

        if ( is_num( *( ptr + i ) ) )
        {
            k = k << 4;
            k |= ( uint32_t )( *( ptr + i ) - '0' );
            if ( n != 0 )
            {
                n++;    //decimal num +1
            }
        }
        if ( *( ptr + i ) == '.' )
        {
            n = 1;
        }
        if ( *( ptr + i ) == ',' || *( ptr + i + 1 ) == ')' )
        {
            if ( m == 4 ||  m == 5 || m == 6 )
            {
                if ( n == 0 || n == 1 )
                {
                    k = k << 4;
                }
            }//start power is 1 bit decimal
            if ( m == 2 )
            {
                if ( n == 0 || n == 1 )
                {
                    k = k << 8;
                }
                if ( n == 2 )
                {
                    k = k << 4;
                }
            }//frequnce data is 2 bits decimal
            *( ( uint32_t * )( &VAFE_MODIFY.conf.mt ) + m ) = k;
            m++;
            n = 0;		//decimal num
            k = 0;
        }
    }
    if ( i < 180 )
    {
        return ( 1 );
    }
    else
    {
        return ( 0 );
    }
}
//===================================================================
//decription    ::  get all calibration meter data from communication
//function      ::  cmd_get_all_calibrate_data
//input         ::  ptr->data first address
//output        ::  1: data format is correct, 0: data format is error
//call          ::  is_num
//effect        ::  VAFE_MODIFY
//===================================================================
uint32_t	cmd_get_all_calibrate_data( uint8_t *ptr )
{
    uint32_t	i, k, m, n;
    m = 0;	   //calibration data num
    n = 0;		//decimal num
    k = 0;      //calibration data
    for ( i = 0; i < 15; i++ )
    {
        if ( *( ptr + i ) == '(' )
        {
            break;
        }
    }
    if ( i >= 10 )
    {
        return ( 0 );
    }
    for ( i = i + 1; i < 180; i++ )
    {
        if ( *( ptr + i ) == ')' )
        {
            break;
        }

        if ( is_num( *( ptr + i ) ) )
        {
            k = k << 4;
            k |= ( uint32_t )( *( ptr + i ) - '0' );
            if ( n != 0 )
            {
                n++;    //decimal num +1
            }
        }
        if ( *( ptr + i ) == '.' )
        {
            n = 1;
        }
        if ( *( ptr + i ) == ',' || *( ptr + i + 1 ) == ')' )
        {
            //if ( m == 7 )
            //{
            //    if ( n == 0 || n == 1 )
            //    {
            //        k = k << 4;
            //    }
            //}//load resitor is 1 bit decimal
            if ( m == 0 || m == 2 || m == 3 || m == 5 || m == 6 || m == 8 )
            {
                if ( n == 0 || n == 1 )
                {
                    k = k << 8;
                }
                if ( n == 2 )
                {
                    k = k << 4;
                }
            }//voltage,phase data is 2 bits decimal
            if ( m == 1 || m == 4 || m == 7 )
            {
                if ( n == 0 || n == 1 )
                {
                    k = k << 12;
                }
                if ( n == 2 )
                {
                    k = k << 8;
                }
                if ( n == 3 )
                {
                    k = k << 4;
                }
            }//current data is 3 bits decimal
            *( ( uint32_t * )( &VAFE_MODIFY.phase_a.urms ) + m ) = k;
            m++;
            n = 0;		//decimal num
            k = 0;
        }
    }
    if ( i < 180 )
    {
        return ( 1 );
    }
    else
    {
        return ( 0 );
    }
}
//===================================================================
//decription    ::  communication protocol process
//function      ::  ComProcess
//input         ::  uart_id
//output        ::  none
//call          ::  none
//effect        ::  none
//===================================================================
void    ComProcess( UART_TYPE uart_id )
{
    uint32_t	i, j;
    uint32_t	cmd;
    uint32_t	len;
    uint32_t	ErrType;
    uint32_t	buff[32];
    UART_str	*ptr;
    ptr = &VCom.Rs485;
    if ( uart_id == Ir_ID )
    {
        ptr = &VCom.IR;
    }
    if ( uart_id == PLC_ID )
    {
        ptr = &VCom.PLC;
    }
    if ( uart_id == ZigBee_ID )
    {
        ptr = &VCom.ZigBee;
    }
    //-------------------------------------------------
    len = 0;
    if ( ( ptr->buff[0] ) == 'C' )
    {
        if ( ( ptr->buff[1] == 'N' ) && ( ptr->buff[2] == 'F' ) )
        {
            i = cmd_get_afe_config_data( &( ptr->buff[3] ) );
            if ( i == 1 )
            {
                __NOP();
                VAFE_MODIFY.conf.mc = bcd_4byte_to_hex( VAFE_MODIFY.conf.mc );
                if ( Configure_AFE( VAFE_MODIFY.conf ) == 1 )
                {
                    const uint8_t *string = "Configure AFE is Ok !";
                    len = SendStringToCMBuff( string, &( ptr->buff[1] ) );
                }
                else
                {
                    const uint8_t *string = "Configure AFE is Failure !";
                    len = SendStringToCMBuff( string, &( ptr->buff[1] ) );
                }
            }
            else
            {
                const uint8_t *string = "Data format is Error !";
                len = SendStringToCMBuff( string, &( ptr->buff[1] ) );
            }
            __NOP();
            __NOP();
        }//cmd ='CNF'
        else
        {
            if ( ( ptr->buff[1] == 'A' ) && ( ptr->buff[2] == 'L' ) && ( ptr->buff[3] == ' ' ) )
            {
                for ( i = 3; i < 8; i++ )
                {
                    if ( ptr->buff[i] != ' ' )
                    {
                        if ( ptr->buff[i] == 'A' || ptr->buff[i] == 'B' \
                                || ptr->buff[i] == 'C' || ptr->buff[i] == 'T' )
                        {
                            break;
                        }
                    }
                }//check cmd
                switch ( ptr->buff[i] )
                {
                    case	'A':
                    {
                        i = cmd_get_all_calibrate_data( &( ptr->buff[3] ) );
                        if ( i == 1 )
                        {
                            VAFE_MODIFY.phase_id = Phase_A;
                            //---triggle calibrating meter message----
                            PutTaskIntoQue( CalMeter );
                            //----------------------------------------
                            const uint8_t *string = "It is calibrating...";
                            len = SendStringToCMBuff( string, &( ptr->buff[1] ) );
                        }
                        else
                        {
                            const uint8_t *string = "Data format is Error !";
                            len = SendStringToCMBuff( string, &( ptr->buff[1] ) );
                        }
                    }
                    break;
                    default:
                    {
                        const uint8_t *string = "CMD is unsupported !";
                        len = SendStringToCMBuff( string, &( ptr->buff[1] ) );
                    }
                    break;
                }
            }//cmd =='CAL x'
            else
            {
                const uint8_t *string = "CMD is unsupported !";
                len = SendStringToCMBuff( string, &( ptr->buff[1] ) );
            }
        }
    }//cmd ='Cxx'
    
    len++;
    ptr->buff[len] = 0x0A;
    len++;
    ptr->buff[len] = 0x0D;	

    ptr->buff[0] =0x0A;
    ptr->len =len+1;
    ptr->state =SEND;
    ptr->Flag.BYTE =0;
    ptr->Flag.BIT.SendDataFlag =1;
    ptr->offset =0;
    ptr->sendtimer =1;		//wait for 5ms =1*5ms
    ptr->overtimer =0;			
    VCom.lamptimer =20;		//10s=20*0.5s
}
//===================================================================
//decription    ::  iec calculate send data bcc
//function      ::  IEC_Cal_TxBcc
//input         ::  ptr->data first address
//					len
//output        ::  bcc (xor code)
//call          ::  none
//effect        ::  none
//===================================================================
uint32_t	IEC_Cal_TxBcc( uint8_t *ptr, uint8_t len )
{
    uint32_t	i;
    uint32_t	bcc;
    bcc = 0;
    for ( i = 0; i < len; i++ )
    {
        bcc ^= *( ptr + i );
    }
    return ( bcc );
}
//===================================================================
//decription    ::  iec calculate receive data bcc
//function      ::  IEC_Cal_RxBcc
//input         ::  ptr->data first address
//output        ::  bcc (xor code)
//call          ::  none
//effect        ::  none
//===================================================================
uint32_t	IEC_Cal_RxBcc( uint8_t *ptr )
{
    uint32_t	i;
    uint32_t	bcc;
    bcc = 0;
    for ( i = 0; i < FRAME_MAX_LEN; i++ )
    {
        if ( *( ptr + i ) == ETX_SYMB )
        {
            break;
        }
        bcc ^= *( ptr + i );
    }
    return ( bcc );
}




/// @cond 0
/**INDENT-OFF**/
#ifdef __cplusplus
}
#endif
/**INDENT-ON**/
/// @endcond