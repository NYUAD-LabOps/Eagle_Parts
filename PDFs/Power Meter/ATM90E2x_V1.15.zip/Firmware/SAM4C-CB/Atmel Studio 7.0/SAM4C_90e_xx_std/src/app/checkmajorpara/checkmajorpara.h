//===================================================================
#ifndef CHECKMAJORPARA_H_INCLUDED
#define CHECKMAJORPARA_H_INCLUDED

#include "compiler.h"

/// @cond 0
/**INDENT-OFF**/
#ifdef __cplusplus
extern "C" {
#endif
/**INDENT-ON**/
/// @endcond

//===================================================================
void    CheckMajorParaProcess(void);

/// @cond 0
/**INDENT-OFF**/
#ifdef __cplusplus
}
#endif
/**INDENT-ON**/
/// @endcond


#endif /* CHECKMAJORPARA_H_INCLUDED */
